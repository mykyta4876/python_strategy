 In folder 'Sentiment_Analysis', there are several excel files (extension:.xlsx).
they have follow columns- "Date Time", "Data", "Team"
I want to find duplication count in Sentiment_Analysis folder based on the data in columns- "Date Time" and "Team" only.

The type of result excel is follow:
let's assume there are 10 excel files in the folder.
 "Date Time", "Team", "Repeat Count", "FileName1", "FileName2", ...,"FileName10"
"FileName1" is name of file1
"FileName2" is name of file2
...
The value of "FileName1" can be 0 or 1.
if 0, File1 has the record.

the name of result excel is "result.xlsx".

